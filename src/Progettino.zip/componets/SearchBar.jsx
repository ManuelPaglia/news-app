import axios from 'axios';
import React, { useState } from 'react';
 
const SearchBar = ({onChange}) => {
  const [searchQuery, setSearchQuery] = useState('');
 
  const handleSearchInputChange = async (event) => {
    setSearchQuery(event.target.value);
    
    try {
        const response = await axios.get(`https://newsapi.org/v2/everything?q=${event.target.value}&apiKey=7eb2e28bad0c474ea2a9e8897426bc21`);
        console.log(response)
        onChange(response["data"]["articles"])
      } catch (error) {
        console.error(error);
      }  
}
 
  const handleSearchSubmit = (event) => {
    event.preventDefault();
    console.log(`Searching for: ${searchQuery}`);
   
  }
 
  return (
    <form onSubmit={handleSearchSubmit}>
      <input
        type="text"
        placeholder="Cerca..."
        value={searchQuery}
        onChange={handleSearchInputChange}
      />
      <button type="submit">Cerca</button>
    </form>
  );
}
 
export default SearchBar;